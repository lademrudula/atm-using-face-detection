from tkinter import *
import os
from PIL import Image, ImageTk

root=Tk()
canvas = Canvas(width = 1000, height = 1000, bg = 'white')

canvas.pack(expand = NO, fill = BOTH)

image = Image.open('C:/Users/chanu/Desktop/Mini_Project_ATM app/atm.jpg')
image = image.resize((350, 350), Image.ANTIALIAS)
my_img = ImageTk.PhotoImage(image)
canvas.create_image(630,420,image = my_img)


lb1 = Label(root, text="WELCOME TO ATM ",font=("Cambria", 25),fg="Purple")
lb1.place(x=480, y=70)
lb2=Label(root,text="AUTOMATIC TELLER MACHINE",font=("Cambria",25),fg="Purple")
lb2.place(x=400,y=150)

def fun():
      root.destroy()
      fname='sim.py'
      os.system(fname)

def fun1():
      root.destroy()
      fname='satm11.py'
      os.system(fname)

btn = Button(root, text="Enter Card",font=("Cambria",15),fg="brown",command=fun1)
btn.place(x=570,y=680)

root.geometry('1200x1200+3+3')
root.mainloop()
from tkinter import *
import face_recognition
import pymysql
pymysql.install_as_MySQLdb()
import MySQLdb
import sys
import os
from tkinter import messagebox
from datetime import date
import cv2
from MySQLdb import Error
from io import BytesIO
from PIL import Image
con = MySQLdb.connect(host="localhost",user="root",passwd="gayathri",db="atm")
print("Connection Succesful")
cur = con.cursor()
print("Cursor created succesfully")
con.autocommit(True)
root=Tk()
def face(accno):
    video_capture = cv2.VideoCapture(0)
    ret, frame = video_capture.read()
    video_capture.release()
    imm = Image.fromarray(frame)
    imm.save("photo1.jpg")
    def readBLOB(accno):
	    print("Reading BLOB data from python_employee table")

	    try:
	        connection = MySQLdb.connect(host='localhost',
	                                             database='atm',
	                                             user='root',
	                                             password='gayathri')

	        cursor = connection.cursor()
	        sql_fetch_blob_query = """SELECT * from imag where accno = %s"""

	        cursor.execute(sql_fetch_blob_query, accno)
	        record = cursor.fetchall()
	        for row in record:
	            image = row[1]
	            file_like= BytesIO(image)
	            img=Image.open(file_like)
	            img.save("C:\\Users\\chanu\\Desktop\\Mini_Project_ATM app\\sss.jpg") 
	    except MySQLdb.Error as error:
	        print("Failed to read BLOB data from MySQL table {}".format(error))

	    finally:
	            cursor.close()
	            connection.close()
	            print("MySQL connection is closed")
    readBLOB(accno)
    known_image = face_recognition.load_image_file("photo1.jpg")
    unknown_image = face_recognition.load_image_file("sss.jpg")
    biden_encoding = face_recognition.face_encodings(known_image)[0]
    unknown_encoding = face_recognition.face_encodings(unknown_image)[0]
    results = face_recognition.compare_faces([biden_encoding], unknown_encoding)
    if results[0]==True:
        return True
    else:
        return False
def pin():
    def check():
        def end():
            root6=Tk()
            label1=Label(root6,text="Thank You For Using ATM",font=("Cambria", 40),fg="indigo").place(x=250,y=300)
            root6.configure(background='white')
            root6.geometry('1000x1000+3+3')
            root6.mainloop()
            fname="ab.py"
            os.system(fname)
        global acc
        global pin
        global bal
        acc=str(entry.get())
        print(acc)
        pin=str(entry1.get())
        print(pin)
        cur.execute("SELECT pin FROM account WHERE accno='"+acc+"'")
        f=cur.fetchone()
        print(f)
        print(type(f))
        p=list(f)
        pinn=p[0]
        print(pinn)
        print(type(pinn))
        if pinn!=pin:
            messagebox.showinfo("Wrong Pin Number")
            root.deiconify()
            end()
        else:
            f=face(acc)
            if f:
                cur.execute("SELECT bal FROM account WHERE accno='"+acc+"'")
                k=cur.fetchone()
                j=list(k)
                bal=j[0]
                con.commit()
                def type1():
                    root.deiconify()
                    window=Tk()
                    Label(window, text="TYPE OF TRANSACTION",font=("Cambria", 30),fg="Purple").place(x=320,y=100)
                    var1 = IntVar()
                    Radiobutton(window, text="savings", variable=var1,command=mode,font=("Cambria",20),fg="green").place(x=450,y=300)
                    var2 = IntVar()
                    Radiobutton(window, text="current", variable=var2,command=mode,font=("Cambria",20),fg="green").place(x=450,y=400)
                    Button(window, text='Cancel Transaction',font=("Cambria",15),fg="brown",command=end).place(x=700,y=500)
                    window.configure(background='white')
                    window.geometry('1000x1000+3+3')
                    window.mainloop()
                def mode():
                    root.deiconify()
                    root1=Tk()
                    lbl = Label(root1, text="MODE OF TRANSACTION",font=("Cambria", 30),fg="Purple")
                    lbl.place(x=320,y=100)
                    var1 = IntVar()
                    Radiobutton(root1, text="WITHDRAW", variable=var1,font=("Cambria",20),fg="green",command=withdraw).place(x=400,y=300)
                    var2 = IntVar()
                    Radiobutton(root1, text="DEPOSIT", variable=var2,font=("Cambria",20),fg="green",command=deposit).place(x=400,y=400)
                    var3 = IntVar()
                    Radiobutton(root1, text="CHECKBALANCE" , variable=var3,font=("Cambria",20),command=checkbalance,fg="green").place(x=400,y=500)
                    Button(root1, text='Cancel Transaction',font=("Cambria",15),command=end,fg="brown").place(x=700,y=600)
                    root1.configure(background='white')
                    root1.geometry('1000x1000+3+3')
                    root1.mainloop()         
                def depre():
                    con = MySQLdb.connect(host="localhost",user="root",passwd="gayathri",db="atm")
                    print("Connection Succesful")
                    cur = con.cursor()
                    print("Cursor created succesfully")
                    con.autocommit(True)
                    root7=Tk()
                    lbl = Label(root7,text="Card Number : "+ acc,font=("Cambria", 20),fg="maroon").place(x=200, y=100)
                    label3=Label(root7,text='Deposit Amount is : '+ str(dep),font=("Cambria",20),fg="maroon").place(x=200,y=200)
                    Label(root7,text="From A/C ",font=("Cambria", 20),fg="maroon").place(x=200, y=300)
                    label4=Label(root7,text='Aval Bal is : '+str(dbal),font=("Cambria",20),fg="maroon").place(x=200,y=400)
                    Button(root7, text='Next',command=end,font=("Cambria",15),fg="brown").place(x=700,y=450)
                    root7.configure(background='white')
                    cur.close()  
                def rcpt():
                    root.deiconify()
                    root5=Tk()
                    con = MySQLdb.connect(host="localhost",user="root",passwd="gayathri",db="atm")
                    print("Connection Succesful")
                    cur = con.cursor()
                    print("Cursor created succesfully")
                    con.autocommit(True)
                    lbl = Label(root5,text="Card Number : "+ acc,font=("Cambria", 20),fg="maroon").place(x=200, y=100)
                    label3=Label(root5,text='Withdrawl Amount is : '+ str(wbal),font=("Cambria",20),fg="maroon").place(x=200,y=200)
                    Label(root5,text="From A/C ",font=("Cambria", 20),fg="maroon").place(x=200, y=300)
                    label4=Label(root5,text='Aval Bal is : '+str(wdraw),font=("Cambria",20),fg="maroon").place(x=200,y=400)
                    Button(root5, text='Next',command=end,font=("Cambria",15),fg="brown").place(x=700,y=450)
                    root5.configure(background='white')
                    root5.geometry('1000x1000+3+3')
                    root5.mainloop()
                    cur.close()         
                def withdraw():
                    def check():
                        con = MySQLdb.connect(host="localhost",user="root",passwd="gayathri",db="atm")
                        print("Connection Succesful")
                        cur = con.cursor()
                        print("Cursor created succesfully")
                        con.autocommit(True)
                        global wbal
                        global wdraw
                        wbal=int(entry.get())
                        print(wbal)
                        if wbal>=100:
                            if wbal<bal:
                                cur.execute("INSERT INTO trans(accno,wdraw,date) VALUES(%s,%s,%s)",(acc,wbal,date.today()))
                                wdraw=bal-wbal
                                cur.execute("UPDATE account SET bal = '"+str(wdraw)+"' WHERE accno = '"+acc+"'")
                                cur.close()
                                rcpt()
                            if wbal>bal:
                                messagebox.showinfo("Insufficient Fund")
                                end()
                        else:
                            messagebox.showinfo("Min bal 100")
                            end()
                    root.deiconify()
                    root2=Tk()
                    lbl = Label(root2,text="WITHDRAW AMOUNT",font=("Cambria", 25),fg="Purple")
                    lbl.place(x=350, y=150)
                    label3=Label(root2,text='Enter Money To Withdraw',font=("Cambria",15),fg="Purple").place(x=200,y=300)
                    entry=Entry(root2,width=50)
                    entry.place(x=600,y=300)
                    Button(root2, text='Cancel Transaction',font=("Cambria",15),command=end,fg="brown").place(x=600,y=400)
                    Button(root2, text='Enter',font=("Cambria",15),fg="brown",command=check).place(x=400,y=400)
                    root2.configure(background='white')
                    root2.geometry('1000x1000+3+3')
                    root2.mainloop()
                def deposit(): 
                    def check():
                        con = MySQLdb.connect(host="localhost",user="root",passwd="gayathri",db="atm")
                        print("Connection Succesful")
                        cur = con.cursor()
                        print("Cursor created succesfully")
                        con.autocommit(True)
                        global dbal
                        global dep
                        dep=int(entry.get())
                        print(dep)
                        cur.execute("SELECT bal FROM account WHERE accno='"+acc+"'")
                        k=cur.fetchone()
                        j=list(k)
                        b=j[0]
                        dbal=dep+b
                        cur.execute("INSERT INTO trans(accno,dep,date) VALUES(%s,%s,%s)",(acc,dep,date.today()))
                        cur.execute("UPDATE account SET bal = '"+str(dbal)+"' WHERE accno = '"+acc+"'")
                        cur.close()
                        depre()
                    root.deiconify()
                    root3=Tk()
                    lbl = Label(root3,text="DEPOSIT AMOUNT",font=("Cambria", 50),fg="Purple")
                    lbl.place(x=350, y=150)
                    label3=Label(root3,text='Enter Money To Deposit',font=("Cambria",20),fg="Purple").place(x=200,y=300)
                    entry=Entry(root3,width=50)
                    entry.place(x=600,y=300)
                    Button(root3, text='Cancel Transaction',font=("Cambria",15),command=end,fg="brown").place(x=600,y=400)
                    Button(root3, text='Enter',command=check,font=("Cambria",15),fg="brown").place(x=400,y=400)
                    root3.configure(background='white')
                    root3.geometry('1000x1000+3+3')
                    root3.mainloop()
                def checkbalance():
                    con = MySQLdb.connect(host="localhost",user="root",passwd="gayathri",db="atm")
                    print("Connection Succesful")
                    cur = con.cursor()
                    print("Cursor created succesfully")
                    con.autocommit(True)
                    root.deiconify()
                    root4=Tk()
                    cur.execute("SELECT bal FROM account WHERE accno='"+acc+"'")
                    b2=cur.fetchone()
                    n=list(b2)
                    c=n[0]
                    lbl = Label(root4,text="Your Balance is "+str(c),font=("Cambria", 50),fg="maroon")
                    lbl.place(x=280, y=50)
                    Button(root4, text='Next',command=end,font=("Cambria",20),fg="brown").place(x=700,y=450)
                    root4.configure(background='white')
                    root4.geometry('1000x1000+3+3')
                    root4.mainloop()
                type1()
            else:
                root.deiconify()
                root8=Tk()
                lbl = Label(root8,text="Your image didn't match",font=("Cambria", 40),fg="indigo")
                lbl.place(x=280, y=100)
                Button(root8, text='Exit',command=end,font=("Cambria",15),fg="brown").place(x=350,y=250)
                root8.configure(background='white')
                root8.geometry('1000x1000+3+3')
                root8.mainloop()
    l = Label(root,text="Enter Account Number",font=('Cambria',15),fg="Purple")
    l.place(x=200, y=250)
    entry=Entry(root,width=20,fg="Purple")
    entry.place(x=500,y=250)
    l1 = Label(root,text="Enter pin Number",font=('Cambria',15),fg="Purple")
    l1.place(x=200, y=300)
    entry1=Entry(root,width=20,show='*',fg="Purple")
    entry1.place(x=500,y=300)
    Button(root, text='submit',command=check,fg="brown",font=('Cambria',15)).place(x=400,y=450)
    root.configure(background="white")
pin()
root.geometry("1000x1000+3+3")
root.mainloop()
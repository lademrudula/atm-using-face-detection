from tkinter import *
import face_recognition
import pymysql
pymysql.install_as_MySQLdb()
import MySQLdb
import sys
import os
from tkinter import messagebox
con = MySQLdb.connect(host="localhost",user="root",passwd="gayathri",db="atm")
print("Connection Succesful")
cur = con.cursor()
print("Cursor created succesfully")
con.autocommit(True)
root=Tk()
def pin():
    def check():
        def end():
            root6=Tk()
            label1=Label(root6,text="Thank You For Using ATM",font=("Cambria", 40),fg="Purple").place(x=50,y=300)
            root6.configure(background='white')
            root6.geometry('1000x1000+3+3')
            root6.mainloop()
            fname="ab.py"
            os.system(fname)
        global acc
        global pin
        global bal
        pin=str(entry.get())
        print(pin)
        cur.execute("SELECT pin FROM acc WHERE pin='"+pin+"'")
        g=cur.fetchone()
        print(g)
        cur.execute("SELECT Id FROM acc WHERE pin='"+pin+"'")
        f=cur.fetchone()
        print(f)
        if f==g:
            messagebox.showinfo("Wrong Pin Number")
            root.deiconify()
            end() 
        print(type(f))
        ac=list(f)
        acc=ac[0]
        print(acc)
        print(type(acc))
        cur.execute("SELECT bal FROM baln WHERE Id='"+acc+"'")
        k=cur.fetchone()
        j=list(k)
        bal=j[0] 
        con.commit()
        if g!=None:
            con.close()
            def type1():
                root.deiconify()
                window=Tk()
                Label(window, text="TYPE OF TRANSACTION",font=("Cambria", "25", "bold italic"),fg="black").place(x=370,y=100)
                var1 = IntVar()
                Radiobutton(window, text="savings", variable=var1,command=mode,font=("Cambria",10),fg="black").place(x=450,y=300)
                var2 = IntVar()
                Radiobutton(window, text="current", variable=var2,command=mode,font=("Cambria",10),fg="black").place(x=450,y=400)
                Button(window, text='Cancel Transaction',font=("Cambria",10),fg="black",command=end).place(x=420,y=500)
                window.configure(background='white')
                window.geometry('1000x1000+3+3')
                window.mainloop()
            def mode():
                root.deiconify()
                root1=Tk()
                lbl = Label(root1, text="MODE OF TRANSACTION",font=("Cambria", 25),fg="black")
                lbl.place(x=370,y=100)
                var1 = IntVar()
                Radiobutton(root1, text="WITHDRAW", variable=var1,font=("Cambria",10),fg="black",command=withdraw).place(x=395,y=300)
                var2 = IntVar()
                Radiobutton(root1, text="DEPOSIT", variable=var2,font=("Cambria",10),fg="black",command=deposit).place(x=400,y=400)
                var3 = IntVar()
                Radiobutton(root1, text="CHECKBALANCE" , variable=var3,font=("Cambria",10),command=checkbalance,fg="black").place(x=385,y=500)
                Button(root1, text='Cancel Transaction',font=("Cambria",15),command=end,fg="black").place(x=420,y=600)
                root1.configure(background='white')
                root1.geometry('1000x1000+3+3')
                root1.mainloop()
            def withdraw():
                root.deiconify()
                def check():
                    con = MySQLdb.connect(host="localhost",user="root",passwd="gayathri",db="atm")
                    print("Connection Succesful")
                    cur = con.cursor()
                    print("Cursor created succesfully")
                    con.autocommit(True)
                    global wbal
                    global wdraw
                    wdraw=int(entry.get())
                    print(wdraw)
                    if wdraw>=100:
                        if wdraw<bal:
                            wdraw=bal-wdraw
                            cur.execute("INSERT INTO trans(Id,wdraw) VALUES(%s,%s)",(acc,wdraw))
                            cur.execute("UPDATE baln SET bal = '"+str(wdraw)+"' WHERE Id = '"+acc+"'")
                            cur.execute("SELECT bal FROM baln WHERE Id='"+acc+"'")
                            b=cur.fetchone()
                            print(b)
                            s=list(b)
                            wbal=s[0]
                            cur.close()
                            rcpt()
                        if wdraw>bal:
                            messagebox.showinfo("Insufficient Fund")
                            end()
                    else:
                        messagebox.showinfo("Min bal 100")
                        end()
                root2=Tk()
                lbl = Label(root2,text="WITHDRAW AMOUNT",font=("Cambria", 25),fg="black")
                lbl.place(x=350, y=50)
                label3=Label(root2,text='Enter Money To Withdraw',font=("Cambria",15),fg="black").place(x=200,y=300)
                entry=Entry(root2,width=50)
                entry.place(x=600,y=300)
                Button(root2, text='Cancel Transaction',font=("Cambria",15),command=end,fg="black").place(x=800,y=400)
                Button(root2, text='Enter',command=check,font=("Cambria",15),fg="black").place(x=600,y=400)
                root2.configure(background='white')
                root2.geometry('1000x1000+3+3')
                root2.mainloop()

            def deposit():
                def check():
                    con = MySQLdb.connect(host="localhost",user="root",passwd="gayathri",db="atm")
                    print("Connection Succesful")
                    cur = con.cursor()
                    print("Cursor created succesfully")
                    con.autocommit(True)
                    global dbal
                    global dep
                    dep=int(entry.get())
                    print(dep)
                    cur.execute("SELECT bal FROM baln WHERE Id='"+acc+"'")
                    k=cur.fetchone()
                    j=list(k)
                    b=j[0]
                    dbal=dep+b
                    cur.execute("INSERT INTO trans(Id,dep) VALUES(%s,%s)",(acc,dep))
                    cur.execute("UPDATE baln SET bal = '"+str(dbal)+"' WHERE Id = '"+acc+"'")
                    b1=cur.fetchone()
                    cur.close()
                    depre()
                root.deiconify()
                root3=Tk()
                lbl = Label(root3,text="DEPOSIT AMOUNT",font=("Cambria", 25))
                lbl.place(x=350, y=50)
                label3=Label(root3,text='Enter Money To Deposit',font=("Cambria",15)).place(x=200,y=300)
                entry=Entry(root3,width=50)
                entry.place(x=600,y=300)
                Button(root3, text='Cancel Transaction',font=("Cambria",15),command=end).place(x=800,y=400)
                Button(root3, text='Enter',command=check,font=("Cambria",15)).place(x=600,y=400)
                root3.configure(background='white')
                root3.geometry('1000x1000+3+3')
                root3.mainloop()
                
            def checkbalance():
                con = MySQLdb.connect(host="localhost",user="root",passwd="gayathri",db="atm")
                print("Connection Succesful")
                cur = con.cursor()
                print("Cursor created succesfully")
                con.autocommit(True)
                root.deiconify()
                root4=Tk()
                cur.execute("SELECT bal FROM baln WHERE Id='"+acc+"'")
                b2=cur.fetchone()
                n=list(b2)
                c=n[0]
                lbl = Label(root4,text="Your Balance is "+str(c),font=("Cambria", 25),fg="black")
                lbl.place(x=260, y=50)
                Button(root4, text='Next',command=end,font=("Cambria",15),fg="black").place(x=800,y=450)
                root4.configure(background='white')
                root4.geometry('1000x1000+3+3')
                root4.mainloop()
            def rcpt():
                    root.deiconify()
                    root5=Tk()
                    con = MySQLdb.connect(host="localhost",user="root",passwd="gayathri",db="atm")
                    print("Connection Succesful")
                    cur = con.cursor()
                    print("Cursor created succesfully")
                    con.autocommit(True)
                
                    lbl = Label(root5,text="Card Number "+ acc,font=("Cambria", 15),fg="black").place(x=200, y=100)
                    label3=Label(root5,text='Withdrawl Amount is :'+ str(wdraw),font=("Cambria",15),fg="black").place(x=200,y=200)
                    Label(root5,text="From A/C ",font=("Cambria", 15),fg="black").place(x=200, y=300)
                    label4=Label(root5,text='Aval Bal is :'+str(wbal),font=("Cambria",15),fg="black").place(x=200,y=400)
                    Button(root5, text='Next',command=end,font=("Cambria",15),fg="black").place(x=800,y=450)
                    root5.configure(background='white')
                    root5.geometry('1000x1000+3+3')
                    root5.mainloop()
                    cur.close()
            

            def depre():
                #root6.destroy()
                
                con = MySQLdb.connect(host="localhost",user="root",passwd="gayathri",db="atm")
                print("Connection Succesful")
                cur = con.cursor()
                print("Cursor created succesfully")
                con.autocommit(True)
                root7=Tk()
                lbl = Label(root7,text="Card Number "+ acc,font=("Cambria", 15),fg="black").place(x=200, y=100)
                label3=Label(root7,text='Deposit Amount is :'+ str(dep),font=("Cambria",15),fg="black").place(x=200,y=200)
                Label(root7,text="From A/C ",font=("Cambria", 15),fg="black").place(x=200, y=300)
                label4=Label(root7,text='Aval Bal is :'+str(dbal),font=("Cambria",15),fg="black").place(x=200,y=400)
                Button(root7, text='Next',command=end,font=("Cambria",15),fg="black").place(x=800,y=450)
                root7.configure(background='white')
                root7.geometry('1000x1000+3+3')
                root7.mainloop()
                cur.close()
            type1()
    l = Label(root,text="Enter PinNumber",font=('Cambria',15),fg="black")
    l.place(x=450, y=250)
    entry=Entry(root,width=15,show='*',fg="black")
    entry.place(x=700,y=250)
    Button(root, text='submit',command=check,fg="black",font=('Cambria',15)).place(x=500,y=300)
    root.configure(background="white")
pin()
root.geometry("1000x1000+3+3")
root.mainloop()

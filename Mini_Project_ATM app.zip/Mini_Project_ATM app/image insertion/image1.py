
import pymysql
pymysql.install_as_MySQLdb()
import MySQLdb
from MySQLdb import Error
from io import BytesIO
from PIL import Image

def readBLOB(accno):
    print("Reading BLOB data from python_employee table")

    try:
        connection = MySQLdb.connect(host='localhost',
                                             database='atm',
                                             user='root',
                                             password='gayathri')

        cursor = connection.cursor()
        sql_fetch_blob_query = """SELECT * from imag where accno = %s"""

        cursor.execute(sql_fetch_blob_query, accno)
        record = cursor.fetchall()
        for row in record:
            image = row[1]
            file_like= BytesIO(image)
            img=Image.open(file_like)
            img.save("C:\\Users\\chanu\\Desktop\\Projects\\priyankaproj\\sss.jpg") 
    except MySQLdb.Error as error:
        print("Failed to read BLOB data from MySQL table {}".format(error))

    finally:
            cursor.close()
            connection.close()
            print("MySQL connection is closed")
readBLOB(6254867896250059)

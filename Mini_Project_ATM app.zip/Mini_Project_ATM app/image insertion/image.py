
import pymysql
pymysql.install_as_MySQLdb()
import MySQLdb
from MySQLdb import Error
def convertToBinaryData(filename):
    with open(filename, 'rb') as file:
        binaryData = file.read()
    return binaryData

def insertBLOB(photo):
    print("Inserting BLOB into python imag table")
    try:
        connection = MySQLdb.connect(host='localhost',
                                             database='atm',
                                             user='root',
                                             password='gayathri')

        cursor = connection.cursor()
        sql_insert_blob_query = " INSERT INTO imag(accno,image) VALUES (%s,%s)"

        picture = convertToBinaryData(photo)
        file = convertToBinaryData(photo)
        #insert_blob_tuple = (/*accountno*/,picture)
        insert_blob_tuple = (8956587965483215,picture)
        result = cursor.execute(sql_insert_blob_query, insert_blob_tuple)
        connection.commit()
        print("Image and file inserted successfully as a BLOB into imag table", result)

    except Error as error:
        print("Failed inserting BLOB data into MySQL table {}",error)

    finally:
            cursor.close()
            connection.close()
            print("MySQL connection is closed")
#insertBLOB(/*photopath*/)
insertBLOB("C:\\Users\\chanu\\Desktop\\jyo.jpg")

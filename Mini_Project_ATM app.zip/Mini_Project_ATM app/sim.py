import face_recognition,cv2
def face():
    video_capture = cv2.VideoCapture(0)
    ret, frame = video_capture.read()
    video_capture.release()
    known_image = face_recognition.load_image_file("photo1.jpg")
    biden_encoding = face_recognition.face_encodings(known_image)[0]
    face_locations = face_recognition.face_locations(frame)
    face_encoding = face_recognition.face_encodings(frame, face_locations)[0]
    results = face_recognition.compare_faces([biden_encoding], face_encoding)
    print(results)
    if results[0]==True:
        return True
    else:
        return False
f=face()



